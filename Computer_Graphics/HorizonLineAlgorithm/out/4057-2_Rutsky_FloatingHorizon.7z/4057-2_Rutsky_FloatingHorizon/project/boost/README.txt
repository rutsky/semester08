Part of Boost v1.43 library.
Downloaded from http://www.boost.org/.

Boost is used for crossplatform uint32_t.
