On Ubuntu 9.10 X86_64 Linux can be used system version of FLTK library v1.1.9.
On Windows this folder contains part of FLTK v1.1.9:
  FL/ - FLTK headers,
  lib/ - dependent built FLTK libraries (only fltk.lib).

FLTK is distributed under terms of GNU LGPL with some exceptions. 
See COPYING.txt for GNU LGPL statements and http://www.fltk.org/COPYING.php
for complete FLTK licensing information.
