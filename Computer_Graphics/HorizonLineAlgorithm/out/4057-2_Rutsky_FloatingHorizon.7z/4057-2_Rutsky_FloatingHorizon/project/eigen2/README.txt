Part of Eigen2 v. 2.0.12 downloaded from <http://eigen.tuxfamily.org>, distributed under GNU GPL v3.

Included only headers.
