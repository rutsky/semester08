HLA - Horizon Line Algorithm implementation.

Copyright (C) 2010  Vladimir Rutsky <altsysrq@gmail.com>


Foreign libraries included in project:

 * Eigen
C++ template library for linear algebra.
http://eigen.tuxfamily.org/
Used under terms of GNU GPL v3 (see eigen2/COPYING).

 * Boost
The Boost C++ Libraries are a collection of open source libraries that extend 
the functionality of C++.
http://www.boost.org/
Used under terms of Boost Software License v1.0 (see boost/LICENSE_1_0.txt).
Only required part of this library was included.

 * FLTK
Crossplatform C++ GUI toolkit.
http://www.fltk.org/
Used under terms of GNU LGPL v2 (see fltk/README.txt).
Only parts required for building on Windows platform included.
